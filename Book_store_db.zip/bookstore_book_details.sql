-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book_details`
--

DROP TABLE IF EXISTS `book_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_details` (
  `author` varchar(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `modify_by` varchar(255) DEFAULT NULL,
  `modify_date` date DEFAULT NULL,
  `price` int NOT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `book_id` int NOT NULL,
  PRIMARY KEY (`book_id`),
  CONSTRAINT `FKowm7t5r8qjacwt8wxeag6l1r` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_details`
--

LOCK TABLES `book_details` WRITE;
/*!40000 ALTER TABLE `book_details` DISABLE KEYS */;
INSERT INTO `book_details` VALUES ('Chetan Bhagat','Romance',NULL,NULL,NULL,'2022-05-01',500,'Romance',2),(' F. Scott Fitzgerald','Novel, Fiction, Tragedy',NULL,NULL,NULL,'2022-05-02',600,'The novel was inspired by a youthful romance Fitzgerald had withand the riotous parties he attended on Long Island\'s',3),('Jane Austen','Fiction, Romance novel',NULL,NULL,NULL,'2022-04-29',1000,'The novel follows the character development of Elizabeth Bennet, the dynamic protagonist of the book who learns about the repercussions of hasty judgments and comes to appreciate the difference between superficial goodness and actual goodness.',4),('JK Rolings','Dramaa',NULL,NULL,NULL,'2022-04-30',3000,'Drama',6),('James Clear','Fiction',NULL,NULL,NULL,'2022-05-04',1000,'Fiction',12),('Jane Austen','Romance','Sharath',NULL,NULL,NULL,3000,'Sense and sensability is a story of two sisters who embody the conflict between the oppressive nature of civilised society and the human desire for romantic passion. The book opens up with their fathers death.',15),('Chetan Bhagat','Fiction',NULL,NULL,NULL,'2022-04-30',800,'One Night @ the Call Center',20),('Kip Thorne','Science Fiction',NULL,NULL,NULL,'2022-04-29',1000,'The Science of Interstellar is a non-fiction book by American theoretical physicist and Nobel laureate Kip Thorne, with a foreword by Christopher Nolan.',22);
/*!40000 ALTER TABLE `book_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-04 16:38:28
