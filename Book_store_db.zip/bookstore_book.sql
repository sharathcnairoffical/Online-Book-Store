-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: bookstore
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `book_id` int NOT NULL,
  `book_image` varchar(255) DEFAULT NULL,
  `book_title` varchar(255) NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `modify_by` varchar(255) DEFAULT NULL,
  `modify_date` date DEFAULT NULL,
  `stockcount` int NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (2,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQM6kt7l2tb2EadtG2hH5mtw9fEhKzXrPyOWw','Half Girlfriend',NULL,NULL,NULL,'2022-05-01',60),(3,'https://www.indiewire.com/wp-content/uploads/2016/08/20140216-131646.jpg','The Originals: Pride and Prejudice',NULL,NULL,NULL,'2022-05-02',100),(4,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSk53mAiLHFnxfACBlj9_G2fS0mLzaNzeJgppiZVcFEVSI5d3w0hwBUFIMedEzpR_Eb4pI','The Great Gatsby',NULL,NULL,NULL,'2022-04-29',200),(6,'https://images.unsplash.com/photo-1611758617024-69b7b77bc4c3?ixlib=rb-1.2.1','Harry Pottor',NULL,NULL,NULL,'2022-04-30',500),(12,'https://th.bing.com/th/id/OIP.ofV49mglrcpDldAyrzaAmAHaFj?pid=ImgDet','Atomic Habits',NULL,NULL,NULL,'2022-05-04',10),(15,'https://images-na.ssl-images-amazon.com/images/I/81Vxq4Qu19L.jpg','Sense and Sensibility','Sharath','2022-04-28',NULL,NULL,5),(20,'https://th.bing.com/th/id/OIP.nMiOmgEkesnWlhoaOtPVGwAAAA?pid=ImgDet','One Night @ the Call Center',NULL,NULL,NULL,'2022-04-30',10),(22,'https://opac.marmot.org/bookcover.php?id=ils:.b43641738','The Science of Interstellar',NULL,NULL,NULL,'2022-04-29',10);
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-04 16:38:23
